<?php 
    include_once 'header.php';
?>
<?php 
    include_once 'sidebar.php';
    include_once 'models/koneksi.php';
    include_once 'c_barang.php';
?>
<?php 
    include_once 'footer.php';
?>